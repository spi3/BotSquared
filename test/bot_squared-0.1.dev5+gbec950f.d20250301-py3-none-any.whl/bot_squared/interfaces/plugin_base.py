from abc import ABC, abstractmethod


class PluginInterface(ABC):

    @abstractmethod
    def __init__(self,
                 plugin_name: str,
                 config: dict):
        pass

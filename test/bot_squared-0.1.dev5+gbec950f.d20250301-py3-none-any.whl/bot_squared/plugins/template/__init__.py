from bot_squared.plugins.template.template import Template


def create_plugin():
    return Template()

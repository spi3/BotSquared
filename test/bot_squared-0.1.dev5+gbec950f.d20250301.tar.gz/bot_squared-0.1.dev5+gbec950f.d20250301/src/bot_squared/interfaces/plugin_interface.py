class PluginInterface:
    def __init__(self):
        self.is_ready: bool = False

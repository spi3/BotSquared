
class Template:

    def __init__(self):
        pass

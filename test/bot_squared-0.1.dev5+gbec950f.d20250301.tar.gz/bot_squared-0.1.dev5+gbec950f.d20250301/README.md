Bot Squared
===================

A python bot of bots. Integrate all your bots together with infinite configurability. 

Developing
===================

Prerequisites: 
```
pipx install hatch
```

Test & Build:
```
hatch run check:all
hatch test
hatch build
```